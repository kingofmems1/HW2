package com.company;

public interface Printable {
    void print();
}
